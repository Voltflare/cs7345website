// Modules to control application life and create native browser window
//If you want to use notifications in the main window, you must grab it
const path = require('path')
const {app, BrowserWindow, Notification, session} = require('electron')

// app.commandLine.appendSwitch('enable-features', 'SharedArrayBuffer')




//makes a new notification and show it - electron API notification in docs
function showNotification () {
  //whenever you have a notification, you need to call "show" on it
  new Notification({title: "Starting Sorting...", body: "Any intermediate progress will be shown in the console window."}).show();
}

function showNotificationEnd () {
  //whenever you have a notification, you need to call "show" on it
  new Notification({title: "Finished Sorting!", body: "Please check the output window for results."}).show();
}

function createWindow () {

  app.commandLine.appendSwitch('enable-features', 'SharedArrayBuffer')

  session.defaultSession.webRequest.onHeadersReceived((details, callback) => {  
    callback({
      responseHeaders: {
         //...details.responseHeaders,
        'Cross-Origin-Opener-Policy': 'same-origin',
        'Cross-Origin-Embedder-Policy': 'require-corp',
      }
    })
  })

  // Create the browser window.
  const mainWindow = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: {
      preload: [
        // path.join(__dirname, 'sorting_functions_with_multi.js'),
        // path.join(__dirname, 'library_with_multi.js') //this is so you can pre-load files
                                                  //instead if simply just forcing waiting
                                                  //for a file to load before calling anything else
      ]
  }
  })

  // and load the index.html of the app- points the window to look at that html file you want
  mainWindow.loadFile('index_with_multi.html').then(showNotificationEnd); //this becomes whatever html is holding the emscripten demo (in my case also index.html in Lab2)

  // Open the DevTools. This is useful because the intermediate things are printed to the console
  mainWindow.webContents.openDevTools()
}


//load --> when "whenReady" is done --> it returns itself which calls create window
// --> which calls the shownotification function
app.whenReady().then(createWindow).then(showNotification);

app.on('activate', function () {
  // On macOS it's common to re-create a window in the app when the
  // dock icon is clicked and there are no other windows open.

  // session.defaultSession.webRequest.onHeadersReceived((details, callback) => {  
  //   callback({
  //     responseHeaders: {
  //       'Cross-Origin-Opener-Policy': 'same-origin',
  //       'Cross-Origin-Embedder-Policy': 'require-corp',
  //     }
  //   })
  // })


  if (BrowserWindow.getAllWindows().length === 0) createWindow()
})

// Quit when all windows are closed, except on macOS. There, it's common
// for applications and their menu bar to stay active until the user quits
// explicitly with Cmd + Q.
app.on('window-all-closed', function () {
  if (process.platform !== 'darwin') app.quit()
})

// In this file you can include the rest of your app's specific main process
// code. You can also put them in separate files and require them here.
