onmessage = event => {
    //event.data[0] = Algo
    //event.data[1] = the array to be sorted
    var t0 = performance.now();
    var sortedArray = event.data[0].Sort.Multi.Merge(event.data[1]);
    var t1 = performance.now();
    let response = ("Seconds: " + (t1-t0)/1000 + "\n");
    postMessage(response);
}